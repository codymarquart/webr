This is a patch release with no expected breakage of any reverse dependencies.

We are maintaining compatibility with an upcoming release of waldo.
