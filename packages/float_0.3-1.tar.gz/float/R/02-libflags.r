blas_ldflags_nix = function() ""

lapack_ldflags_nix = function() ""
